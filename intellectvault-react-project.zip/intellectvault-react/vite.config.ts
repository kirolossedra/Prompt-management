import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";

export default defineConfig({
  plugins: [react()],
  build: {
    sourcemap: true,
    target: "baseline-widely-available",
  },
  server: {
    port: 5173,
    strictPort: true,
  },
});
